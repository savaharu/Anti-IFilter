window.onload = () => {

    document.getElementById('id_button2').onclick = () => {

        window.open('src/I-Filter回避用ツール(URL版)/main.html','_blank');

    }
    
    document.getElementById('id_crgames').onclick = () => {
    
        window.open('src/crazygames/main.html','_blank');
    
    }
    
    document.getElementById('id_scratch').onclick = () => {
    
        window.open('src/scratch/main.html','_blank');
    
    }
    
    
    document.getElementById('id_toge').onclick = () => {
    
        window.open('src/TotallyGeometry(神)/main.html','_blank');
    
    }

}